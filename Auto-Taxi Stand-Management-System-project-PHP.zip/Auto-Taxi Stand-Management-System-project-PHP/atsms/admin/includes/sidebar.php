<aside class="menu-sidebar d-none d-lg-block">
            <div class="logo">
        
                   <h1>ATSMS</h1>
            </div>
            <div class="menu-sidebar__content js-scrollbar1">
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">
                        <li>
                            <a href="dashboard.php"  style="color: blue">
                                <i class="fas fa-tachometer-alt"></i>Dashboard</a>
                        </li>

     <li>
                            <a href="new-autoortaxi-entry-form.php"  style="color: blue">
                                <i class="fa fa-taxi" aria-hidden="true"></i>New Auto/Taxi Entry</a>
                        </li>


<li class="has-sub">
<a class="js-arrow" href="#">
<i class="fas fa-taxi"></i>Manage Auto/Taxi Entry</a>
<ul class="list-unstyled navbar__sub-list js-sub-list" style="display: none;">
<li>
<a href="manage-taxies-entry.php">Taxies</a>
</li>
<li>
<a href="manage-autos-entry.php">Autos</a>
</li>
<li>
<a href="manage-autoortaxi-entry.php">All</a>
</li>
</ul>
</li>


                       

                        
                      <li>
                            <a href="bwdates-reports.php"  style="color: blue">
                                <i class="fas fa-copy"></i> Between Dates Report</a>
                        </li>  
                       
                    </ul>
                </nav>
            </div>
        </aside>