<div class="row">
                            <div class="col-md-12">
                                <div class="copyright">
                                    <p style="color: darkred;">Auto/Taxi Stand Management System. All rights reserved.</p>
                                </div>
                            </div>
                        </div>